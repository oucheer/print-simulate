# RK3588 Printer Simulation PoC v0.2 - Runtime Findings

## 当前真实证据

- `mfp.afx`：ELF64 AArch64，动态链接，带 `.debug_*` 与 `.symtab`，未 strip。
- `mfp.afx` 解释器：`/lib/ld-linux-aarch64.so.1`。
- `mfp.afx` 直接依赖包含 `libhal.so`、`libcommon.so`、`libevent_mgr.so`、`libosal.so`、`libipm.so` 等。
- `main()` 启动顺序中明确存在 `hal_prolog()`，随后才进入大量打印/扫描/存储/网络模块。
- `hal_prolog()` 第一关键动作是 `pi_hal_init()`，成功后还会走 `pi_hal_wifi_request/load`。
- `libhal.so` 自身也是 AArch64、未 strip、带 debug info。
- `libhal.so` 存在 `pi_hal_virt_request/getinfo/platform/free`。
- `hal_module_config.json` 中存在 `virtual_platform`，设备名是 `qemu_platform`。
- `pwm` 模块配置为 `json_node=virtual`。
- `mfp.afx` 中真实存在 GPIO、纸路、电机、打印流程等符号/字符串。
- 启动脚本 `rc.local` 会启动 `service_manager`、`event_mgr_service`、`hal_daemon`，然后启动 `/usr/bin/mfp.afx`。

## 当前结论

第一阶段不应该模拟完整激光打印物理链路。优先验证：

`真实 rootfs + 真实 mfp.afx + 真实 libhal.so -> AArch64 Linux/QEMU-user -> HAL 初始化`。

只有当 `mfp.afx` 在虚拟运行环境进入稳定运行态之后，再根据实际访问的设备节点、HAL module、IPC 和错误日志逐项增加 Virtual Device。

## 当前环境限制

当前执行环境没有安装 `qemu-aarch64` / `qemu-aarch64-static`，因此 v0.2 没有声称“真实 mfp.afx 已经在本机运行”。运行入口已准备好，拿到 QEMU 后可以直接进入下一验证阶段。
