#!/usr/bin/env bash
set -euo pipefail
ROOT=${1:-runtime-root}
QEMU=${QEMU_AARCH64:-qemu-aarch64-static}
MFP="$ROOT/usr/bin/mfp.afx"
if ! command -v "$QEMU" >/dev/null 2>&1; then
  echo "ERROR: qemu-aarch64-static not found." >&2
  echo "Install qemu-user-static or set QEMU_AARCH64=/path/to/qemu-aarch64-static." >&2
  exit 127
fi
if [ ! -x "$MFP" ]; then echo "ERROR: $MFP not found" >&2; exit 2; fi
export QEMU_LD_PREFIX="$(cd "$ROOT" && pwd)"
export LD_LIBRARY_PATH="$QEMU_LD_PREFIX/usr/lib:$QEMU_LD_PREFIX/lib:$QEMU_LD_PREFIX/lib64"
exec "$QEMU" -L "$QEMU_LD_PREFIX" "$MFP"
