param(
  [string]$Root = "runtime-root",
  [string]$Qemu = $env:QEMU_AARCH64
)
if ([string]::IsNullOrWhiteSpace($Qemu)) { $Qemu = "qemu-aarch64.exe" }
$Mfp = Join-Path $Root "usr/bin/mfp.afx"
if (-not (Test-Path $Mfp)) { throw "Missing $Mfp. Run prepare_runtime.py first." }
if (-not (Get-Command $Qemu -ErrorAction SilentlyContinue)) { throw "qemu-aarch64(.exe) not found. Install QEMU or set QEMU_AARCH64." }
$env:QEMU_LD_PREFIX = (Resolve-Path $Root).Path
$env:LD_LIBRARY_PATH = "$($env:QEMU_LD_PREFIX)/usr/lib;$($env:QEMU_LD_PREFIX)/lib;$($env:QEMU_LD_PREFIX)/lib64"
& $Qemu -L $env:QEMU_LD_PREFIX $Mfp
exit $LASTEXITCODE
