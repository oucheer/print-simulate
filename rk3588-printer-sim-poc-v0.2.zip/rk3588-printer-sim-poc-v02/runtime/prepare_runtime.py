#!/usr/bin/env python3
"""Prepare a minimal AArch64 user-mode runtime from the real rootfs image.

This does not modify the source firmware. It extracts the real mfp.afx,
its directly declared libraries, the ELF interpreter, and selected runtime
configuration. The full rootfs can be added later once a QEMU execution
probe is available.
"""
from __future__ import annotations
import argparse, json, re, subprocess
from pathlib import Path
import sys
sys.path.insert(0, str(Path(__file__).resolve().parents[1] / 'tools'))
from poc import Ext4Reader

ROOTFS_RE = re.compile(r"^(.*)$")

def read_elf_deps(p: Path):
    out = subprocess.check_output(['readelf','-d',str(p)], text=True, errors='replace')
    deps=[]; interp=None
    for line in out.splitlines():
        if '(NEEDED)' in line:
            m=re.search(r'\[(.*?)\]',line)
            if m: deps.append(m.group(1))
    ph = subprocess.check_output(['readelf','-l',str(p)], text=True, errors='replace')
    m=re.search(r'Requesting program interpreter: (.*?)\]',ph)
    if m: interp=m.group(1)
    return deps, interp

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('rootfs')
    ap.add_argument('-o','--out',default='runtime-root')
    args=ap.parse_args()
    rootfs=Path(args.rootfs); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    er=Ext4Reader(rootfs)
    mfp=out/'usr/bin/mfp.afx'; mfp.parent.mkdir(parents=True,exist_ok=True)
    er.extract('usr/bin/mfp.afx',mfp)
    deps,interp=read_elf_deps(mfp)
    targets=['usr/bin/mfp.afx']
    if interp: targets.append(interp.lstrip('/'))
    for dep in deps:
        candidates=[f'usr/lib/{dep}',f'lib/{dep}',f'lib64/{dep}']
        found=None
        for c in candidates:
            if er.find(c): found=c; break
        if found:
            targets.append(found)
    configs=[
      'etc/hal_module_config.json','etc/gpio.json','etc/generic_power.json',
      'etc/led.json','etc/inittab','etc/init.d/rcS','etc/rc.d/rc.local'
    ]
    targets += configs
    extracted=[]
    for t in dict.fromkeys(targets):
        ino=er.find(t)
        if ino:
            dst=out/t; dst.parent.mkdir(parents=True,exist_ok=True)
            mode,size=er.extract(t,dst)
            extracted.append({'path':t,'size':size,'mode':oct(mode)})
    er.close()
    result={'mfp':str(mfp),'interpreter':interp,'needed':deps,'extracted':extracted}
    (out/'runtime-manifest.json').write_text(json.dumps(result,indent=2,ensure_ascii=False))
    print(json.dumps(result,indent=2,ensure_ascii=False))

if __name__=='__main__': main()
