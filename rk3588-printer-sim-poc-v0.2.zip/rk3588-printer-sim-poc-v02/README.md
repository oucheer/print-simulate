# RK3588 Printer Simulation PoC v0.2

## 目标

继续推进到“真实 `mfp.afx` 在 AArch64 Linux/QEMU-user 中启动”的最小验证，不修改生产固件业务逻辑。

## 当前已经从真实固件确认的关键点

1. `mfp.afx` 是 AArch64 ELF64、动态链接、带 debug 信息和符号表。
2. `main()` 明确调用 `hal_prolog()`。
3. `hal_prolog()` 的第一关键硬件入口是 `pi_hal_init()`，随后是 Wi-Fi HAL。
4. `libhal.so` 本身带 debug 信息，并实现 `pi_hal_virt_*`。
5. HAL 配置明确出现 `virtual_platform` / `qemu_platform`，PWM 还存在 `virtual` 配置。
6. 启动脚本会启动 `hal_daemon`，再启动 `mfp.afx`。

因此 v0.2 不再猜打印物理模型，而是先验证真实软件栈的启动链。

## 主路径

```text
update.img
  -> rootfs.ext4
  -> mfp.afx + real libraries
  -> ARM64 user-mode runtime
  -> real libhal
  -> real hal virtual-platform path
  -> observe first runtime blocker
```

## 使用

### 1. 从真实 rootfs 准备运行目录

```bash
python3 tools/poc.py inspect /path/to/update.img -o poc-out
python3 runtime/prepare_runtime.py poc-out/package/Image/rootfs.ext4 -o runtime-root
```

### 2. 检查 QEMU

```bash
qemu-aarch64-static --version
```

Debian 提供 `qemu-user-static`，其中包含 `qemu-aarch64-static`；QEMU user-mode 可以在 x86 主机上启动另一 CPU 架构的 Linux 进程。详见 QEMU / Debian 文档。

### 3. 启动真实 mfp

```bash
runtime/run-mfp-qemu.sh runtime-root
```

Windows 可使用：

```powershell
powershell -ExecutionPolicy Bypass -File runtime/run-mfp-qemu.ps1 -Root runtime-root
```

## 重要边界

这一版没有声称“完整打印已经仿真成功”。真正的第一个验收条件是：

> 真实 `mfp.afx` 进入 `main()`，完成 `hal_prolog()`，并输出/记录下一处真实依赖失败点或继续进入后续模块。

一旦拿到这一条运行轨迹，就可以据实际报错决定第一个 Virtual Device / IPC / 文件系统依赖，而不是猜。
